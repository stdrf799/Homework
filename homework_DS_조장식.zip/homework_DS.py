#import package
import pandas as pd
import numpy as np
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from patsy import dmatrices
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
import matplotlib.pyplot as plt
import seaborn as sns
import math
import tensorflow as tf
from keras import models
from keras import layers

#figure feature analysis
def figure_analysis(figure_data, target_data, type):
    col = figure_data.name
    if type == 'category' :
        fig = plt.figure()
        figure_data.value_counts().plot(kind='bar')
        plt.savefig('graph\{0}.png'.format(col))
    elif type == 'numeric' :
        fig = plt.figure()
        ax1 = plt.subplot(1,2,1)
        sns.distplot(figure_data.loc[figure_data.notnull()])
        plt.title(col)
        ax2 = plt.subplot(1,2,2)
        sns.boxplot(data=figure_data)
        plt.title(col)
        plt.savefig('graph\{0}.png'.format(col))
        fig = plt.figure()
        sns.jointplot(x=col, y='MEDV', data=pd.concat([housing_data[col],housing_data[target_data.name]],axis=1), kind='scatter')
        plt.title(col)
        plt.savefig('graph\{0}_scatter.png'.format(col))

#Calcurate FunctionR square
def calculation_rsquare(actual_value, predict_value):
    mean_square = np.dot(np.array(actual_value-actual_value.mean()).transpose(),np.array(actual_value-actual_value.mean()))
    error_square = np.dot((np.array(actual_value)-np.array(predict_value)).transpose(),(np.array(actual_value)-predict_value))
    return 1-(error_square/mean_square)

#Set function forecast model by Deep Neural Network 
def set_dnn():
    np.random.seed(0)
    model = models.Sequential()
    model.add(layers.Dense(128,activation='relu',input_shape=(X_train_std.shape[1],)))
    model.add(layers.Dense(128,activation='relu' ))
    model.add(layers.Dense(1))
    model.compile(optimizer='rmsprop', loss='mse', metrics=['mse'])
    return model


if __name__ == "__main__":
    # Load data
    housing_data = pd.read_csv('housing.data', delimiter='\s+',
                      names=['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX', 'RM', 'AGE', 'DIS','RAD', 'TAX', 'PTRATIO', 'B','LSTAT', 'MEDV']) 
    
    ###Exploratory data analysis
    #Check data
    housing_data.head()
    housing_data.info()
    
    #Change data type of dummy variable 
    housing_data['CHAS'] = housing_data['CHAS'].astype(object)
    #Summary basic statistical details 
    housing_data.describe().to_csv('result\data_describe.csv')
    #Check missing value
    print(housing_data.isnull().sum())
    
    ##Figure feature analysis
    #Get category variable
    category_variable = [col for col in housing_data.columns if housing_data[col].dtypes == 'object']
    #Get target variable
    target_variable = housing_data.columns[len(housing_data.columns)-1]
    #Get numeric variable
    numeric_variable = list(set(housing_data.columns)-set(category_variable)-set(target_variable))
    #Figure category variable analysis
    for col in category_variable:
        figure_analysis(housing_data[col],housing_data[target_variable], 'category')
    #Figure numeric variable analysis
    for col in numeric_variable:
        figure_analysis(housing_data[col], housing_data[target_variable], 'numeric')
    #Figure target variable analysis
    figure_analysis(housing_data[target_variable], housing_data[target_variable], 'numeric')
  
    #Calculate correlation
    corr = housing_data.corr(method = 'pearson')
    plt.figure(figsize=(len(corr.index), len(corr.columns)))
    sns.heatmap(data = corr,annot= True,fmt = '.2f', linewidths = .5, cmap = 'Blues')
    plt.savefig('graph\correlation.png')

    ##Check multicollinearity
    #Calculate vif for checking multicollinearity
    features = '+'.join(housing_data.columns[0:len(housing_data.columns)-1])
    y,X = dmatrices('MEDV ~' + features, housing_data, return_type = 'dataframe')
    vif = pd.DataFrame()
    vif['VIF_FACTOR'] = [variance_inflation_factor(X.values,i) for i in range(X.shape[1])]
    vif['features'] = X.columns
    print(vif)
    
    ###Forecast Modeling 
    
    ##Variable selection 
    #Drop variable ('INDUS','RAD','TAX')
    #housing_model_data = housing_data
    housing_model_data = housing_data.drop(['ZN','RAD'],axis=1)

    ##Prepare Training and Test dataset 
    #Get model feature
    X = housing_model_data[housing_model_data.columns[0:len(housing_model_data.columns)-1]]
    #Get Target feature
    y= housing_model_data[housing_model_data.columns[len(housing_model_data.columns)-1]]
    
    #PCA example
    #pca = PCA(n_components = 5)
    #principalComponent = pca.fit_transform(X)
    #X = pd.DataFrame(data = principalComponent, columns = ['p1','p2','p3','p4','p5'])

    #Divide tranin, test data
    X_train, X_test, y_train, y_test = train_test_split(X,y,test_size =0.3, random_state = 0)

    #check outlier
    outlier_thrd =  X_train.mean()+3*X_train.std()
    for col in X_train.columns:
        X_train.loc[X_train[col] > outlier_thrd[col],col] = outlier_thrd[col]
        X_test.loc[X_test[col] > outlier_thrd[col],col] = outlier_thrd[col]
    
    #Transform standard scaler
    standard_scaler = StandardScaler()
    standard_scaler.fit(X_train)
    X_train_std = standard_scaler.transform(X_train)
    X_test_std = standard_scaler.transform(X_test)

    ##Train model and check validation 

    result_forecast=[]
    
    ##Random Forest
    #Set forecast model by random forest regression
    model_random_forest = RandomForestRegressor(n_estimators = 500, criterion='mse', max_depth=10,random_state=0, oob_score = True)
    #Train model
    model_random_forest.fit(X_train_std, y_train)
    #Predict traning and test data by random forest
    y_pred_train = pd.DataFrame(model_random_forest.predict(X_train_std))
    y_pred_test = pd.DataFrame(model_random_forest.predict(X_test_std))
    #Calcurate R square by randomforest
    score_random_forest_train = calculation_rsquare(pd.DataFrame(y_train), y_pred_train)
    score_random_forest_test = calculation_rsquare(pd.DataFrame(y_test), y_pred_test)
    #Merge R square by random forest
    result_random_forest = np.append(score_random_forest_train,score_random_forest_test)
    #Merge Forecast Value
    y_pred_test.index = y_test.index.values
    forecast_value = pd.concat([pd.DataFrame(y_test),y_pred_test],axis = 1)
    forecast_value.columns = ['Actual', 'Random Forest']
    #Calculate feature importances by random forest
    feature_importances = pd.DataFrame(model_random_forest.feature_importances_,index =
                                       X.columns,columns=['importance']).sort_values('importance',ascending=False)
    print(feature_importances)
    feature_importances.to_csv('result\\feature_importances.csv')

    ##Decision Tree
    #Set forecast model by decsion tree regression
    model_decision_tree = DecisionTreeRegressor( criterion='mse', max_depth=10,random_state=0)
    #Train model
    model_decision_tree.fit(X_train_std, y_train)
    #Predict traning and test data by decsion tree
    y_pred_train = pd.DataFrame(model_decision_tree.predict(X_train_std))
    y_pred_test = pd.DataFrame(model_decision_tree.predict(X_test_std))
    #Calcurate R square by decsion tree
    score_decision_tree_train = calculation_rsquare(pd.DataFrame(y_train), y_pred_train)
    score_decision_tree_test = calculation_rsquare(pd.DataFrame(y_test), y_pred_test)
    #Merge R square by decsion tree
    result_decision_tree = np.append(score_decision_tree_train,score_decision_tree_test)
    #Merge Forecast result
    result_forecast = np.vstack((result_random_forest,result_decision_tree))
    #Merge Forecast Value
    y_pred_test.index = y_test.index.values
    y_pred_test.columns = ['Decision Tree']
    forecast_value = pd.concat([forecast_value,y_pred_test],axis = 1)
    
    ##Gradient Boosting Regression
    #Set forecast model by Gradient Boosting Regression
    model_gradient_boosting = GradientBoostingRegressor(n_estimators = 500, max_depth=10,random_state=0)
    #Train model
    model_gradient_boosting.fit(X_train_std, y_train)
    #Predict traning and test data by Gradient Boosting
    y_pred_train = pd.DataFrame(model_gradient_boosting.predict(X_train_std))
    y_pred_test = pd.DataFrame(model_gradient_boosting.predict(X_test_std))
    #Calcurate R square by Gradient Boosting
    score_gradient_boosting_train = calculation_rsquare(pd.DataFrame(y_train), y_pred_train)
    score_gradient_boosting_test = calculation_rsquare(pd.DataFrame(y_test), y_pred_test)
    #Merge R square by Gradient Boosting
    result_gradient_boosting = np.append(score_gradient_boosting_train,score_gradient_boosting_test)
    #Merge forecast result
    result_forecast = np.vstack((result_forecast,result_gradient_boosting))
    #Merge Forecast Value
    y_pred_test.index = y_test.index.values
    y_pred_test.columns = ['Gradient Boosting']
    forecast_value = pd.concat([forecast_value,y_pred_test],axis = 1)

    ##Deep Neural Network 
    #Set Deep neural network
    model_deep_neural_network = set_dnn()
    #Train model
    model_deep_neural_network.fit(X_train_std, y_train, validation_split=0.2, epochs=200, batch_size=1)
    #Predict traning and test data by DNN
    y_pred_train = pd.DataFrame(model_deep_neural_network.predict(X_train_std))
    y_pred_test = pd.DataFrame(model_deep_neural_network.predict(X_test_std))
    #Calcurate R square by DNN
    score_deep_neural_network_train = calculation_rsquare(pd.DataFrame(y_train), y_pred_train)
    score_deep_neural_network_test = calculation_rsquare(pd.DataFrame(y_test), y_pred_test)
    #Merge R square by Gradient Boosting
    result_deep_neural_network = np.append(score_deep_neural_network_train,score_deep_neural_network_test)
    result_forecast = np.vstack((result_forecast,result_deep_neural_network))
    #Merge Forecast Value
    y_pred_test.index = y_test.index.values
    y_pred_test.columns = ['Deep Neural Network']
    forecast_value = pd.concat([forecast_value,y_pred_test],axis = 1)


    #Output Forecast Result
    result_forecast = pd.DataFrame(result_forecast, columns = ['Train R Square', 'Test R Square'], index = ['Random Forest', 'Decision Tree', 'Gradient Boosting','Deep Neural Network'])
    print(result_forecast)
    result_forecast.to_csv('result\\forecast_result.csv')
    forecast_value.to_csv('result\\forecast_value.csv')



